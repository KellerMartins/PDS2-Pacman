var searchData=
[
  ['inky',['Inky',['../class_inky.html',1,'']]]
];
